
export default{
	stuCount:"",
	stuTimeOut:"",
	stuName:"",
	stuCard:"",
	stuBrrCount:0,
	manCount:"",
	manName:"",
	admCount:"",
	admName:"",
	
	setStuBrrCount(stuBrrCount){
		this.stuBrrCount=stuBrrCount;
	},
	setStuTimeOut(stuTimeOut){
		this.stuTimeOut=stuTimeOut;
	},
	setStuCard(stuCard){
		this.stuCard=stuCard;
	},
	setStuCount(stuCount){
		this.stuCount=stuCount;
	},setManCount(manCount){
		this.manCount=manCount;
	},
	setAdmCount(admCount){
		this.admCount=admCount;
	},
	
	setStuName(stuName){
		this.stuName=stuName;
	},
	setManName(manName){
		this.manName=manName;

	},setAdmName(admName){
		this.admName=admName;
	}
}

